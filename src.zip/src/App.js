import 'bootstrap/dist/css/bootstrap.min.css';
import ProductBox from './Componenets/Card/ProductBox';
// import CartArea from './Componenets/CartArea/CartArea';
// import Navbar from './Componenets/Navbar/Navbar'
import './App.css';
import Shop from './Componenets/Shop/Shop';

// import { useState, useEffect } from "react";

function App() {
  return (
    <div>
  
   <Shop></Shop>



      {/* <ProductBox></ProductBox> */}
       {/* <Navbar></Navbar>  */} 
    </div>
  );
}

export default App;
